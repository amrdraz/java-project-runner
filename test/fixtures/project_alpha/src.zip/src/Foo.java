public class Foo {
    public static int returnAFive(){return 5;}
}